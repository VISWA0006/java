# College Management (Hibernate + Swing)

Courses, students, semester results and fees using Hibernate ORM, HQL joins,
native SQL and a Java Swing UI.

## Run
Requires JDK 17+ and Maven.

    mvn compile exec:java

An embedded H2 database is created in ./data on first run, with sample data.

## Use MySQL instead
1. Add to pom.xml:
   <dependency>
     <groupId>com.mysql</groupId>
     <artifactId>mysql-connector-j</artifactId>
     <version>8.3.0</version>
   </dependency>
2. In hibernate.cfg.xml comment out the H2 properties and uncomment the MySQL block.

## Where things are
- model/       ORM entities (@Entity, @ManyToOne, @OneToMany)
- service/     AcademicService: ORM CRUD, HQL joins, native SQL
- ui/          Swing tabs: Courses & Students, Results, Fees, Reports
