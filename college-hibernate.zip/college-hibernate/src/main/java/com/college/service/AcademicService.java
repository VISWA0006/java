package com.college.service;

import com.college.model.*;
import com.college.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;
import java.util.function.Function;

/** All database work (ORM + HQL joins + native SQL) lives here. */
public class AcademicService {

    private <T> T run(Function<Session, T> work) {
        try (Session s = HibernateUtil.factory().openSession()) {
            Transaction tx = s.beginTransaction();
            try {
                T result = work.apply(s);
                tx.commit();
                return result;
            } catch (RuntimeException e) {
                tx.rollback();
                throw e;
            }
        }
    }

    // ---------- ORM: create / read ----------

    public void addCourse(String name, int semesters, double feePerSem) {
        run(s -> { s.persist(new Course(name, semesters, feePerSem)); return null; });
    }

    public List<Course> courses() {
        return run(s -> s.createQuery("from Course order by name", Course.class).list());
    }

    public void addStudent(String rollNo, String name, String email, Course course) {
        run(s -> {
            Course managed = s.get(Course.class, course.getId());
            s.persist(new Student(rollNo, name, email, managed));
            return null;
        });
    }

    /** HQL JOIN FETCH: loads each student together with its course in one query. */
    public List<Student> students() {
        return run(s -> s.createQuery(
                "select st from Student st join fetch st.course order by st.rollNo",
                Student.class).list());
    }

    public void addResult(Long studentId, int semester, String subject, int marks) {
        run(s -> {
            Student st = s.get(Student.class, studentId);
            s.persist(new SemesterResult(st, semester, subject, marks));
            return null;
        });
    }

    public void addPayment(Long studentId, int semester, double amount) {
        run(s -> {
            Student st = s.get(Student.class, studentId);
            s.persist(new FeePayment(st, semester, amount));
            return null;
        });
    }

    // ---------- HQL with joins ----------

    public List<SemesterResult> resultsOf(Long studentId) {
        return run(s -> s.createQuery(
                "select r from SemesterResult r join r.student st " +
                "where st.id = :id order by r.semester, r.subject",
                SemesterResult.class).setParameter("id", studentId).list());
    }

    public List<FeePayment> paymentsOf(Long studentId) {
        return run(s -> s.createQuery(
                "select p from FeePayment p join p.student st " +
                "where st.id = :id order by p.semester, p.paidOn",
                FeePayment.class).setParameter("id", studentId).list());
    }

    /** Report 1: student + course + semester average (3-way join, GROUP BY). */
    public List<Object[]> semesterAverages() {
        return run(s -> s.createQuery(
                "select st.rollNo, st.name, c.name, r.semester, avg(r.marks) " +
                "from Student st join st.course c join st.results r " +
                "group by st.rollNo, st.name, c.name, r.semester " +
                "order by st.rollNo, r.semester",
                Object[].class).list());
    }

    /** Report 2: fee total, paid and balance per student (LEFT JOIN so unpaid students still show). */
    public List<Object[]> feeStatus() {
        return run(s -> s.createQuery(
                "select st.rollNo, st.name, c.name, (c.feePerSem * c.semesters), coalesce(sum(p.amount), 0.0) " +
                "from Student st join st.course c left join st.payments p " +
                "group by st.id, st.rollNo, st.name, c.name, c.feePerSem, c.semesters " +
                "order by st.rollNo",
                Object[].class).list());
    }

    /** Report 3: students with at least one failed subject (marks < 50). */
    public List<Object[]> arrearList() {
        return run(s -> s.createQuery(
                "select st.rollNo, st.name, r.semester, r.subject, r.marks " +
                "from SemesterResult r join r.student st " +
                "where r.marks < 50 order by st.rollNo, r.semester",
                Object[].class).list());
    }

    // ---------- Native SQL ----------

    /** Report 4: course-wise student count and fee collected (plain SQL with LEFT JOINs). */
    @SuppressWarnings("unchecked")
    public List<Object[]> courseSummary() {
        return run(s -> s.createNativeQuery(
                "SELECT c.name, COUNT(DISTINCT st.id) AS students, COALESCE(SUM(p.amount), 0) AS collected " +
                "FROM course c " +
                "LEFT JOIN student st ON st.course_id = c.id " +
                "LEFT JOIN fee_payment p ON p.student_id = st.id " +
                "GROUP BY c.name ORDER BY c.name").list());
    }
}
