package com.college;

import com.college.model.Course;
import com.college.service.AcademicService;
import com.college.ui.MainFrame;
import com.college.util.HibernateUtil;

import javax.swing.*;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        AcademicService svc = new AcademicService();
        seedIfEmpty(svc);
        SwingUtilities.invokeLater(() -> new MainFrame(svc).setVisible(true));
        Runtime.getRuntime().addShutdownHook(new Thread(HibernateUtil::shutdown));
    }

    private static void seedIfEmpty(AcademicService svc) {
        if (!svc.courses().isEmpty()) return;
        svc.addCourse("B.E. Computer Science", 8, 45000);
        svc.addCourse("B.Tech Information Technology", 8, 48000);
        svc.addCourse("MBA", 4, 60000);

        List<Course> cs = svc.courses();
        Course cse = cs.get(0);
        svc.addStudent("CS001", "Arun Kumar", "arun@college.edu", cse);
        svc.addStudent("CS002", "Priya S", "priya@college.edu", cse);

        Long arun = svc.students().get(0).getId();
        Long priya = svc.students().get(1).getId();
        svc.addResult(arun, 1, "Mathematics", 78);
        svc.addResult(arun, 1, "Programming", 92);
        svc.addResult(priya, 1, "Mathematics", 45);
        svc.addResult(priya, 1, "Programming", 88);
        svc.addPayment(arun, 1, 45000);
        svc.addPayment(priya, 1, 20000);
    }
}
