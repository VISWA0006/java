package com.college.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "fee_payment")
public class FeePayment {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "student_id")
    private Student student;

    private int semester;
    private double amount;
    private LocalDate paidOn = LocalDate.now();

    public FeePayment() {}
    public FeePayment(Student student, int semester, double amount) {
        this.student = student; this.semester = semester; this.amount = amount;
    }

    public Long getId() { return id; }
    public Student getStudent() { return student; }
    public void setStudent(Student student) { this.student = student; }
    public int getSemester() { return semester; }
    public void setSemester(int semester) { this.semester = semester; }
    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }
    public LocalDate getPaidOn() { return paidOn; }
    public void setPaidOn(LocalDate paidOn) { this.paidOn = paidOn; }
}
