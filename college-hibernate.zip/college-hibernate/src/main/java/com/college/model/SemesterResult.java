package com.college.model;

import jakarta.persistence.*;

@Entity
@Table(name = "semester_result")
public class SemesterResult {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "student_id")
    private Student student;

    private int semester;
    private String subject;
    private int marks;

    public SemesterResult() {}
    public SemesterResult(Student student, int semester, String subject, int marks) {
        this.student = student; this.semester = semester; this.subject = subject; this.marks = marks;
    }

    /** Grade derived from marks (not stored). */
    @Transient
    public String getGrade() {
        if (marks >= 91) return "O";
        if (marks >= 81) return "A+";
        if (marks >= 71) return "A";
        if (marks >= 61) return "B+";
        if (marks >= 56) return "B";
        if (marks >= 50) return "C";
        return "U";
    }

    public Long getId() { return id; }
    public Student getStudent() { return student; }
    public void setStudent(Student student) { this.student = student; }
    public int getSemester() { return semester; }
    public void setSemester(int semester) { this.semester = semester; }
    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }
    public int getMarks() { return marks; }
    public void setMarks(int marks) { this.marks = marks; }
}
