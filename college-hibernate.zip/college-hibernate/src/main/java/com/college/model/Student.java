package com.college.model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "student")
public class Student {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String rollNo;

    @Column(nullable = false)
    private String name;

    private String email;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "course_id")
    private Course course;

    @OneToMany(mappedBy = "student", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<SemesterResult> results = new ArrayList<>();

    @OneToMany(mappedBy = "student", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<FeePayment> payments = new ArrayList<>();

    public Student() {}
    public Student(String rollNo, String name, String email, Course course) {
        this.rollNo = rollNo; this.name = name; this.email = email; this.course = course;
    }

    public Long getId() { return id; }
    public String getRollNo() { return rollNo; }
    public void setRollNo(String rollNo) { this.rollNo = rollNo; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public Course getCourse() { return course; }
    public void setCourse(Course course) { this.course = course; }
    public List<SemesterResult> getResults() { return results; }
    public List<FeePayment> getPayments() { return payments; }

    @Override public String toString() { return rollNo + " - " + name; }
}
