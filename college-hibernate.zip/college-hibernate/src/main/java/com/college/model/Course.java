package com.college.model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "course")
public class Course {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String name;

    private int semesters;      // total semesters in the course
    private double feePerSem;   // fee charged each semester

    @OneToMany(mappedBy = "course")
    private List<Student> students = new ArrayList<>();

    public Course() {}
    public Course(String name, int semesters, double feePerSem) {
        this.name = name; this.semesters = semesters; this.feePerSem = feePerSem;
    }

    public Long getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getSemesters() { return semesters; }
    public void setSemesters(int semesters) { this.semesters = semesters; }
    public double getFeePerSem() { return feePerSem; }
    public void setFeePerSem(double feePerSem) { this.feePerSem = feePerSem; }
    public List<Student> getStudents() { return students; }

    @Override public String toString() { return name; }
}
