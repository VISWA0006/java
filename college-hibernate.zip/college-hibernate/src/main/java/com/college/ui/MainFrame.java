package com.college.ui;

import com.college.model.*;
import com.college.service.AcademicService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class MainFrame extends JFrame {
    private final AcademicService svc;

    private final JComboBox<Course> courseBox = new JComboBox<>();
    private final JComboBox<Student> resultStudent = new JComboBox<>();
    private final JComboBox<Student> feeStudent = new JComboBox<>();

    private final DefaultTableModel studentModel = model("Roll No", "Name", "Email", "Course");
    private final DefaultTableModel resultModel = model("Semester", "Subject", "Marks", "Grade");
    private final DefaultTableModel feeModel = model("Semester", "Amount", "Paid On");
    private final DefaultTableModel reportModel = model();

    public MainFrame(AcademicService svc) {
        super("College Management - Hibernate + Swing");
        this.svc = svc;
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(900, 560);
        setLocationRelativeTo(null);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Courses & Students", studentsTab());
        tabs.addTab("Semester Results", resultsTab());
        tabs.addTab("Fees", feesTab());
        tabs.addTab("Reports", reportsTab());
        add(tabs);

        refreshAll();
    }

    // ---------------- Tab 1: courses + students ----------------
    private JPanel studentsTab() {
        JTextField cName = new JTextField(12), cSems = new JTextField(3), cFee = new JTextField(7);
        JButton addCourse = new JButton("Add Course");
        addCourse.addActionListener(e -> guard(() -> {
            svc.addCourse(cName.getText().trim(), Integer.parseInt(cSems.getText().trim()),
                    Double.parseDouble(cFee.getText().trim()));
            cName.setText(""); cSems.setText(""); cFee.setText("");
            refreshAll();
        }));
        JPanel coursePanel = flow("New course:", "Name", cName, "Semesters", cSems, "Fee/sem", cFee, addCourse);

        JTextField roll = new JTextField(6), name = new JTextField(10), email = new JTextField(12);
        JButton addStudent = new JButton("Add Student");
        addStudent.addActionListener(e -> guard(() -> {
            Course c = (Course) courseBox.getSelectedItem();
            if (c == null) throw new IllegalStateException("Add a course first");
            svc.addStudent(roll.getText().trim(), name.getText().trim(), email.getText().trim(), c);
            roll.setText(""); name.setText(""); email.setText("");
            refreshAll();
        }));
        JPanel studentPanel = flow("New student:", "Roll", roll, "Name", name, "Email", email,
                "Course", courseBox, addStudent);

        JPanel north = new JPanel(new GridLayout(2, 1));
        north.add(coursePanel); north.add(studentPanel);

        JPanel p = new JPanel(new BorderLayout());
        p.add(north, BorderLayout.NORTH);
        p.add(new JScrollPane(new JTable(studentModel)), BorderLayout.CENTER);
        return p;
    }

    // ---------------- Tab 2: results ----------------
    private JPanel resultsTab() {
        JSpinner sem = new JSpinner(new SpinnerNumberModel(1, 1, 12, 1));
        JTextField subject = new JTextField(12), marks = new JTextField(4);
        JButton add = new JButton("Add Result");
        add.addActionListener(e -> guard(() -> {
            Student st = (Student) resultStudent.getSelectedItem();
            if (st == null) throw new IllegalStateException("Select a student");
            int m = Integer.parseInt(marks.getText().trim());
            if (m < 0 || m > 100) throw new IllegalArgumentException("Marks must be 0-100");
            svc.addResult(st.getId(), (Integer) sem.getValue(), subject.getText().trim(), m);
            subject.setText(""); marks.setText("");
            loadResults();
        }));
        resultStudent.addActionListener(e -> loadResults());

        JPanel top = flow("Student:", resultStudent, "Sem", sem, "Subject", subject, "Marks", marks, add);
        JPanel p = new JPanel(new BorderLayout());
        p.add(top, BorderLayout.NORTH);
        p.add(new JScrollPane(new JTable(resultModel)), BorderLayout.CENTER);
        return p;
    }

    // ---------------- Tab 3: fees ----------------
    private JPanel feesTab() {
        JSpinner sem = new JSpinner(new SpinnerNumberModel(1, 1, 12, 1));
        JTextField amount = new JTextField(8);
        JButton pay = new JButton("Record Payment");
        pay.addActionListener(e -> guard(() -> {
            Student st = (Student) feeStudent.getSelectedItem();
            if (st == null) throw new IllegalStateException("Select a student");
            svc.addPayment(st.getId(), (Integer) sem.getValue(), Double.parseDouble(amount.getText().trim()));
            amount.setText("");
            loadPayments();
        }));
        feeStudent.addActionListener(e -> loadPayments());

        JPanel top = flow("Student:", feeStudent, "Sem", sem, "Amount", amount, pay);
        JPanel p = new JPanel(new BorderLayout());
        p.add(top, BorderLayout.NORTH);
        p.add(new JScrollPane(new JTable(feeModel)), BorderLayout.CENTER);
        return p;
    }

    // ---------------- Tab 4: reports (joins + native SQL) ----------------
    private JPanel reportsTab() {
        String[] names = {
                "Semester averages (HQL 3-table join)",
                "Fee status per student (HQL LEFT JOIN)",
                "Arrear list - marks below 50 (HQL join)",
                "Course summary (native SQL)"
        };
        JComboBox<String> box = new JComboBox<>(names);
        JButton run = new JButton("Run");
        run.addActionListener(e -> guard(() -> {
            switch (box.getSelectedIndex()) {
                case 0 -> show(new String[]{"Roll No", "Name", "Course", "Semester", "Avg Marks"},
                        svc.semesterAverages());
                case 1 -> showFees(svc.feeStatus());
                case 2 -> show(new String[]{"Roll No", "Name", "Semester", "Subject", "Marks"},
                        svc.arrearList());
                default -> show(new String[]{"Course", "Students", "Fee Collected"},
                        svc.courseSummary());
            }
        }));
        JPanel top = flow("Report:", box, run);
        JPanel p = new JPanel(new BorderLayout());
        p.add(top, BorderLayout.NORTH);
        p.add(new JScrollPane(new JTable(reportModel)), BorderLayout.CENTER);
        return p;
    }

    private void showFees(List<Object[]> rows) {
        reportModel.setDataVector(new Object[0][0],
                new String[]{"Roll No", "Name", "Course", "Total Fee", "Paid", "Balance"});
        for (Object[] r : rows) {
            double total = ((Number) r[3]).doubleValue(), paid = ((Number) r[4]).doubleValue();
            reportModel.addRow(new Object[]{r[0], r[1], r[2], total, paid, total - paid});
        }
    }

    private void show(String[] cols, List<Object[]> rows) {
        reportModel.setDataVector(new Object[0][0], cols);
        for (Object[] r : rows) {
            Object[] row = r.clone();
            for (int i = 0; i < row.length; i++) {
                if (row[i] instanceof Double d) row[i] = Math.round(d * 100.0) / 100.0;
            }
            reportModel.addRow(row);
        }
    }

    // ---------------- data loading ----------------
    private void refreshAll() {
        courseBox.removeAllItems();
        svc.courses().forEach(courseBox::addItem);

        studentModel.setRowCount(0);
        List<Student> students = svc.students();
        for (Student s : students) {
            studentModel.addRow(new Object[]{s.getRollNo(), s.getName(), s.getEmail(), s.getCourse().getName()});
        }
        resultStudent.removeAllItems();
        feeStudent.removeAllItems();
        for (Student s : students) { resultStudent.addItem(s); feeStudent.addItem(s); }
    }

    private void loadResults() {
        resultModel.setRowCount(0);
        Student st = (Student) resultStudent.getSelectedItem();
        if (st == null) return;
        for (SemesterResult r : svc.resultsOf(st.getId())) {
            resultModel.addRow(new Object[]{r.getSemester(), r.getSubject(), r.getMarks(), r.getGrade()});
        }
    }

    private void loadPayments() {
        feeModel.setRowCount(0);
        Student st = (Student) feeStudent.getSelectedItem();
        if (st == null) return;
        for (FeePayment p : svc.paymentsOf(st.getId())) {
            feeModel.addRow(new Object[]{p.getSemester(), p.getAmount(), p.getPaidOn()});
        }
    }

    // ---------------- small helpers ----------------
    private void guard(Runnable r) {
        try { r.run(); }
        catch (NumberFormatException ex) { error("Please enter valid numbers."); }
        catch (Exception ex) {
            Throwable t = ex; while (t.getCause() != null) t = t.getCause();
            error(String.valueOf(t.getMessage()));
        }
    }

    private void error(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private static DefaultTableModel model(String... cols) {
        return new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
    }

    /** Builds a flow panel from a mix of labels (String) and components. */
    private static JPanel flow(Object... parts) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 6));
        for (Object o : parts) {
            if (o instanceof String s) p.add(new JLabel(s));
            else p.add((Component) o);
        }
        return p;
    }
}
